file(REMOVE_RECURSE
  "CMakeFiles/clmc.dir/config.cpp.obj"
  "CMakeFiles/clmc.dir/config.cpp.obj.d"
  "CMakeFiles/clmc.dir/filesystem.cpp.obj"
  "CMakeFiles/clmc.dir/filesystem.cpp.obj.d"
  "CMakeFiles/clmc.dir/help.cpp.obj"
  "CMakeFiles/clmc.dir/help.cpp.obj.d"
  "CMakeFiles/clmc.dir/info.cpp.obj"
  "CMakeFiles/clmc.dir/info.cpp.obj.d"
  "CMakeFiles/clmc.dir/main.cpp.obj"
  "CMakeFiles/clmc.dir/main.cpp.obj.d"
  "CMakeFiles/clmc.dir/usage.cpp.obj"
  "CMakeFiles/clmc.dir/usage.cpp.obj.d"
  "clmc.exe"
  "clmc.exe.manifest"
  "clmc.pdb"
  "libclmc.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/clmc.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
