# Empty dependencies file for clmc.
# This may be replaced when dependencies are built.
